package pt.ulusofona.cm.kotlin.challenge.exceptions

import java.lang.Exception

class MenorDeIdadeException (mensagem : String) : Exception(mensagem){
}
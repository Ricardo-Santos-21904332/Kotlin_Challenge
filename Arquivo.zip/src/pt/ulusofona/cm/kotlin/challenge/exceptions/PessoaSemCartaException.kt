package pt.ulusofona.cm.kotlin.challenge.exceptions

import java.lang.Exception

class PessoaSemCartaException(mensagem : String) : Exception(mensagem) {
}
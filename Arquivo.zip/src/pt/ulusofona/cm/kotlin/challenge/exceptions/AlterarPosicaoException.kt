package pt.ulusofona.cm.kotlin.challenge.exceptions

import java.lang.Exception

class AlterarPosicaoException(mensagem : String) : Exception(mensagem) {
}